---
title: Classwork - 6
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---
::: tip In Class Test
Consider the following graph $G$. Find $q(\mu)$ in Corollary 1.26 and the spectrum of $G$.

![G](../images/Classwork_6.png)
:::