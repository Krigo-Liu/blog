---
title: Classwork - 1
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---
::: tip In Class Test
Find the adjacency matrix, its squire and cube of the following graph $G$.

![G](../images/Classwork_1.png)

How many walks from $v_1$ to $v_2$ of length $3$? 

List all such walks one by one.
:::
