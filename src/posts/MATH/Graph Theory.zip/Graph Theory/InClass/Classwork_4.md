---
title: Classwork - 4
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---
::: tip In Class Test
Find the characteristic polynomial of adjacent matrix of the following graph by Theorem 1.7, 1.17 and 1.18. 

![G](../images/Classwork_5.png)
:::