---
title: Classwork - 18
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---

::: tip In Class Test - 18
Calculate all Laplacian eigenpairs of the following graph $G$.
![Classwork 18](../images/Classwork_18.png)
:::