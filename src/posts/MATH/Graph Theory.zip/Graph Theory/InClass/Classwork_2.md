---
title: Classwork - 2
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---
::: tip In Class Test
Let $G$ be the following graph. Find the characteristic polynomial of $A(G)$. Verify Theorem 1.8.

![G](../images/Classwork_2.png)
:::