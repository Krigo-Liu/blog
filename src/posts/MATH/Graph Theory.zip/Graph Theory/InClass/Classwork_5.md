---
title: Classwork - 5
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---

::: tip In Class Test
Consider the following graph G and Corollary 1.26. Suppose $q(\mu) = (\mu^2 - \alpha)(\mu^3 - 3)(\mu + b), a,b>0$ and $q(A(G)) = 24J$. Find the spectrum of the graph.

![G](../images/Classwork_5.png)
:::