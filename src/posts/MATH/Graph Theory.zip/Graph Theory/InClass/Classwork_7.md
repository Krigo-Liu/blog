---
title: Classwork - 7
icon: file
order: 3
author: Krigo
category:
    - MATH
tag: 
    - MATH
    - Graph Theory
    - Classwork
footer: Thank's for my Dr.ChiuFai WONG
copyrigh: 无版权
---
::: tip In Class Test - 7
Let $\lambda$ be an eigenvalue of the adjacency matrix of a line graph of $G$. Show that $\lambda \geq 2$.
:::